// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "forge-std/Script.sol";
import "../src/LandRegistry.sol";

/**
 * @title DeployLandRegistry
 * @notice Foundry deployment script for Base Sepolia testnet.
 *
 * Usage:
 *   forge script script/Deploy.s.sol \
 *     --rpc-url $BASE_SEPOLIA_RPC_URL \
 *     --private-key $PRIVATE_KEY \
 *     --broadcast \
 *     --verify \
 *     --etherscan-api-key $BASESCAN_API_KEY \
 *     -vvvv
 */
contract DeployLandRegistry is Script {

    function run() external returns (LandRegistry registry) {
        address admin = vm.envOr("ADMIN_ADDRESS", msg.sender);

        console.log("=== Land Registry Deployment ===");
        console.log("Chain ID     :", block.chainid);
        console.log("Deployer     :", msg.sender);
        console.log("Admin        :", admin);

        vm.startBroadcast();
        registry = new LandRegistry(admin);
        vm.stopBroadcast();

        console.log("Deployed to  :", address(registry));
        console.log("NEXT_PUBLIC_CONTRACT_ADDRESS=", address(registry));
    }
}
