"use client";

import { useReadContract, useWriteContract, useWaitForTransactionReceipt, useAccount, useChainId } from "wagmi";
import { useState, useCallback } from "react";
import { LAND_REGISTRY_ABI, LAND_REGISTRY_ADDRESS, ADMIN_ROLE, REGISTRAR_ROLE } from "@/lib/contract";
import type { TxState } from "@/types";

// ─── Base hook returning typed contract config ────────────────────────────────

function contractArgs() {
  return { address: LAND_REGISTRY_ADDRESS, abi: LAND_REGISTRY_ABI } as const;
}

// ─── Read hooks ───────────────────────────────────────────────────────────────

export function useLand(landId: bigint | undefined) {
  return useReadContract({
    ...contractArgs(),
    functionName: "getLand",
    args:         landId !== undefined ? [landId] : undefined,
    query:        { enabled: landId !== undefined },
  });
}

export function useOwnerLands(owner: `0x${string}` | undefined) {
  return useReadContract({
    ...contractArgs(),
    functionName: "getLandsByOwner",
    args:         owner ? [owner] : undefined,
    query:        { enabled: !!owner },
  });
}

export function useTransferHistory(landId: bigint | undefined) {
  return useReadContract({
    ...contractArgs(),
    functionName: "getTransferHistory",
    args:         landId !== undefined ? [landId] : undefined,
    query:        { enabled: landId !== undefined },
  });
}

export function usePendingTransfer(landId: bigint | undefined) {
  return useReadContract({
    ...contractArgs(),
    functionName: "getPendingTransfer",
    args:         landId !== undefined ? [landId] : undefined,
    query:        { enabled: landId !== undefined },
  });
}

export function useTotalLands() {
  return useReadContract({
    ...contractArgs(),
    functionName: "totalLands",
  });
}

export function useIsAdmin(account: `0x${string}` | undefined) {
  return useReadContract({
    ...contractArgs(),
    functionName: "hasRole",
    args:         account ? [ADMIN_ROLE, account] : undefined,
    query:        { enabled: !!account },
  });
}

export function useIsRegistrar(account: `0x${string}` | undefined) {
  return useReadContract({
    ...contractArgs(),
    functionName: "hasRole",
    args:         account ? [REGISTRAR_ROLE, account] : undefined,
    query:        { enabled: !!account },
  });
}

export function useIsPaused() {
  return useReadContract({
    ...contractArgs(),
    functionName: "paused",
  });
}

// ─── Write hooks (generic pattern) ───────────────────────────────────────────

export function useContractWrite() {
  const { writeContractAsync } = useWriteContract();
  const [txState, setTxState] = useState<TxState>({ status: "idle" });

  const { isLoading: isConfirming } = useWaitForTransactionReceipt({
    hash: txState.hash,
  });

  const execute = useCallback(
    async (
      functionName: string,
      args: unknown[],
      onSuccess?: (hash: `0x${string}`) => void
    ) => {
      try {
        setTxState({ status: "pending", message: "Waiting for wallet..." });

        const hash = await writeContractAsync({
          ...contractArgs(),
          functionName: functionName as never,
          args:         args as never,
        });

        setTxState({ status: "confirming", hash, message: "Transaction sent. Confirming..." });
        onSuccess?.(hash);
        // Note: caller should watch isConfirming to know when finalized
        return hash;
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : "Transaction failed";
        setTxState({ status: "error", message: msg });
        throw err;
      }
    },
    [writeContractAsync]
  );

  const reset = useCallback(() => setTxState({ status: "idle" }), []);

  return { execute, txState, isConfirming, reset };
}

// ─── Convenience role hook ────────────────────────────────────────────────────

export function useRoles() {
  const { address } = useAccount();
  const { data: isAdmin }     = useIsAdmin(address);
  const { data: isRegistrar } = useIsRegistrar(address);
  return {
    address,
    isAdmin:     !!isAdmin,
    isRegistrar: !!isRegistrar,
    canRegister: !!isAdmin || !!isRegistrar,
  };
}
