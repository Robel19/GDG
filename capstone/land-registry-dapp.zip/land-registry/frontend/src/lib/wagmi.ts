import { getDefaultConfig } from "@rainbow-me/rainbowkit";
import { baseSepolia, base } from "wagmi/chains";

export const config = getDefaultConfig({
  appName:     "Land Registry | Base Chain",
  projectId:   process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID ?? "YOUR_PROJECT_ID",
  chains:      [baseSepolia, base],
  ssr:         true,
});

export { baseSepolia, base };
export const TARGET_CHAIN = baseSepolia; // switch to `base` for mainnet
